/**
 * Class that contains the credentials for the sales system.
 */
public class Secrets {
    /**
     * Get the email address of the sales system.
     * @return The email address of the sales system.
     */
    public String getEmail() {
        return "abc.xyz@ejemplo.com";
    }

    /**
     * Get the password of the email address of the sales system.
     * @return The password of the email address of the sales system.
     */
    public String getPassword() {
        return "**********";
    }

    /**
     * Get the string that represents the Oracle connection.
     * @return The string that represents the Oracle connection.
     */
    public String getOracleCon() {
        return "jdbc:oracle:thin:@localhost:1539/XEPDB1";
    }

    /**
     * Get the string of the IP of the server.
     * @return The string of the IP of the server.
     */
    public String getLocalHostIP() {
        return "localhost";
    }

    /**
     * Get the port where the webservices are running.
     * @return The port where the webservices are running.
     */
    public String getWebServerPort() {
        return "3003";
    }
}
